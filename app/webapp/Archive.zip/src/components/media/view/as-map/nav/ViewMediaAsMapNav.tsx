import React from "react";
import { Button, Tooltip } from "@material-ui/core";
import NavBar from "~/components/pure/affordances/NavBar";
import { RouteComponentProps, withRouter } from "react-router-dom";
import { useAppliedFilter } from "~/redux/media-filter/useAppliedFilter";
import { useIsDesktop } from "~/components/media/useIsDesktop";
import Logo from "~/components/pure/affordances/Logo";
import DynamicFeedIcon from "@material-ui/icons/DynamicFeed";

interface Props extends RouteComponentProps<{}> {}

const ViewMediaAsMapNav: React.FunctionComponent<Props> = ({
  history,
  children
}) => {
  const { appliedFilter } = useAppliedFilter();
  const isDesktop = useIsDesktop();

  return (
    <NavBar
      leftSlot={<Logo />}
      rightSlot={
        <Tooltip
          title={
            appliedFilter.activeMediaId && isDesktop
              ? "View In Feed"
              : "View Feed"
          }
        >
          <Button
            color="inherit"
            onClick={() => {
              if (!isDesktop) {
                window.location.pathname = "/";
              } else {
                history.push(
                  // Due to a difficult to trace scrolling bug in IOS Safari, don't allow direct
                  // linking from the map page to the feed
                  appliedFilter.activeMediaId
                    ? `/?activeMediaId=${appliedFilter.activeMediaId}`
                    : "/"
                );
              }
            }}
          >
            <DynamicFeedIcon />
          </Button>
        </Tooltip>
      }
    >
      {children}
    </NavBar>
  );
};

export default withRouter(ViewMediaAsMapNav);
