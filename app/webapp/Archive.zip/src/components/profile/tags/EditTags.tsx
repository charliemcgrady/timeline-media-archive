import React, { FunctionComponent, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { AppState } from "~/redux/store";
import { tagActions } from "~/redux/actions";
import LoadingSpinner from "~/components/pure/affordances/LoadingSpinner";
import EditTagsNav from "./EditTagsNav";

const EditTags: FunctionComponent<{}> = () => {
  const dispatch = useDispatch();
  const { fetchLoading } = useSelector(
    (state: AppState) => state.userData.tags
  );

  useEffect(() => {
    dispatch(tagActions.fetchTags());
  }, []);

  return <EditTagsNav>{fetchLoading && <LoadingSpinner />}</EditTagsNav>;
};

export default EditTags;
