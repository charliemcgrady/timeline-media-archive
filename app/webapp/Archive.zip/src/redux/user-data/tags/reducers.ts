import {
  TagActionTypes,
  TagState,
  PendingSync,
  FETCH_TAGS_PENDING,
  FETCH_TAGS_ERROR,
  FETCH_TAGS_SUCCESS,
  SYNC_TAGS_PENDING,
  SYNC_TAGS_ERROR,
  SYNC_TAGS_SUCCESS
} from "./types";
import { TagMap, TagEdge } from "~/rgb-commons/types/tags";

export default (
  state = {
    tagMap: {} as TagMap,
    tagEdges: [] as Array<TagEdge>,
    fetchLoading: false,
    fetchError: false,
    pendingSync: {
      tagsToDelete: [],
      tagsToAddOrUpdate: [],
      tagEdgesToDelete: [],
      tagEdgesToAddOrUpdate: []
    } as PendingSync,
    syncLoading: false,
    syncError: false
  } as TagState,
  action: TagActionTypes
): TagState => {
  switch (action.type) {
    case FETCH_TAGS_PENDING: {
      return {
        ...state,
        fetchError: false,
        fetchLoading: true
      };
    }
    case FETCH_TAGS_ERROR: {
      return {
        ...state,
        fetchError: true,
        fetchLoading: false
      };
    }
    case FETCH_TAGS_SUCCESS: {
      return {
        ...state,
        tagEdges: action.payload.tagEdges,
        tagMap: action.payload.tagMap,
        fetchLoading: false,
        fetchError: false
      };
    }
    case SYNC_TAGS_PENDING: {
      return {
        ...state,
        syncError: false,
        syncLoading: true
      };
    }
    case SYNC_TAGS_ERROR: {
      return {
        ...state,
        syncError: true,
        syncLoading: false
      };
    }
    case SYNC_TAGS_SUCCESS: {
      return {
        ...state,
        tagEdges: action.payload.tagEdges,
        tagMap: action.payload.tagMap,
        pendingSync: {
          tagsToDelete: [],
          tagsToAddOrUpdate: [],
          tagEdgesToDelete: [],
          tagEdgesToAddOrUpdate: []
        },
        syncLoading: false,
        syncError: false
      };
    }
    default:
      return state;
  }
};
